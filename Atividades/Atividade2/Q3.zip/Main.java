class Main {
  public static void main(String[] args) {
    int a = 8, b = 5, c = 4, d = 2;

    boolean y;

    y = (a > 8) && (b + c > d);

    System.out.println(y);    
  }
}