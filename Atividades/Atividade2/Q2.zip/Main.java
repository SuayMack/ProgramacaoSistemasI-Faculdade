class Main {
  public static void main(String[] args) {
    int num = 10;
    float media = 8.3F;

    System.out.printf("O aluno de número %d \nobteve nota final %.1f\n", num, media);    
  }
}